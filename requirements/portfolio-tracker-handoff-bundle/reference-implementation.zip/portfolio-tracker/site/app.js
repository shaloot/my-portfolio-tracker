/* Portfolio — static frontend. Reads precomputed JSON; no logic beyond render. */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const money = (v, ccy) => {
    const loc = ccy === "INR" ? "en-IN" : "en-US";
    return new Intl.NumberFormat(loc, {
      style: "currency", currency: ccy, maximumFractionDigits: 0,
    }).format(v);
  };
  const moneyPrecise = (v, ccy) => {
    const loc = ccy === "INR" ? "en-IN" : "en-US";
    return new Intl.NumberFormat(loc, {
      style: "currency", currency: ccy, maximumFractionDigits: 2,
    }).format(v);
  };
  const pct = (v) => (v >= 0 ? "+" : "") + v.toFixed(2) + "%";
  const signClass = (v) => (v > 0 ? "pos" : v < 0 ? "neg" : "muted");
  const arrow = (v) => (v > 0 ? "▲" : v < 0 ? "▼" : "·");

  const svgNS = "http://www.w3.org/2000/svg";
  const el = (name, attrs) => {
    const n = document.createElementNS(svgNS, name);
    for (const k in attrs) n.setAttribute(k, attrs[k]);
    return n;
  };

  async function load() {
    try {
      const [p, h, n] = await Promise.all([
        fetch("data/portfolio.json").then((r) => { if (!r.ok) throw 0; return r.json(); }),
        fetch("data/history.json").then((r) => r.ok ? r.json() : { series: [] }),
        fetch("data/news.json").then((r) => r.ok ? r.json() : { market: [], by_symbol: {} }),
      ]);
      render(p, h, n);
    } catch (e) {
      $("app").hidden = true;
      $("error").hidden = false;
    }
  }

  function render(p, hist, news) {
    const base = p.base_currency;
    const t = p.totals;

    // Masthead
    document.title = (p.title || "Portfolio");
    $("owner").textContent = "End-of-day snapshot";
    const dt = new Date(p.generated_at);
    $("updated").textContent = "Updated " + dt.toLocaleDateString(undefined,
      { day: "2-digit", month: "short", year: "numeric" });
    $("basecc").textContent = base + " base";
    const anyStale = p.holdings.some((r) => r.stale);
    if (anyStale) $("freshdot").classList.add("stale");

    // Hero figures
    $("total-value").textContent = money(t.value_base, base);
    setSigned($("day-change"), t.day_base, t.day_pct, base);
    setSigned($("total-pnl"), t.pnl_base, t.pnl_pct, base);
    $("total-cost").textContent = money(t.cost_base, base);

    drawChart(hist, base);
    marketSplit(p.holdings);
    rows(p.holdings, base);
    renderNews(news, p.holdings);

    $("app").setAttribute("aria-busy", "false");
  }

  function setSigned(node, abs, percent, base) {
    node.className = "fig-md " + signClass(abs);
    node.textContent = `${arrow(abs)} ${money(Math.abs(abs), base)} (${pct(percent)})`;
  }

  /* ---- Signature: cost-basis waterline chart ------------------ */
  function drawChart(hist, base) {
    const host = $("chart");
    host.innerHTML = "";
    const series = (hist && hist.series) || [];
    if (series.length < 2) { host.innerHTML = '<p class="muted mono" style="font-size:12px">Chart appears after the first daily build.</p>'; return; }

    const W = 700, H = 230, padL = 8, padR = 8, padT = 14, padB = 22;
    const vals = series.map((d) => d.value_base);
    const cost = series[series.length - 1].cost_base;
    const lo = Math.min(...vals, cost), hi = Math.max(...vals, cost);
    const span = (hi - lo) || 1;
    const pad = span * 0.12;
    const yMin = lo - pad, yMax = hi + pad;

    const x = (i) => padL + (i / (series.length - 1)) * (W - padL - padR);
    const y = (v) => padT + (1 - (v - yMin) / (yMax - yMin)) * (H - padT - padB);
    const costY = y(cost);

    const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, preserveAspectRatio: "none" });

    // clip bands: above the waterline (profit) and below (loss)
    const defs = el("defs", {});
    const cTop = el("clipPath", { id: "cTop" });
    cTop.appendChild(el("rect", { x: 0, y: 0, width: W, height: Math.max(0, costY) }));
    const cBot = el("clipPath", { id: "cBot" });
    cBot.appendChild(el("rect", { x: 0, y: costY, width: W, height: Math.max(0, H - costY) }));
    defs.appendChild(cTop); defs.appendChild(cBot);
    svg.appendChild(defs);

    // area polygon between the value curve and the waterline
    let d = `M ${x(0).toFixed(1)} ${y(vals[0]).toFixed(1)}`;
    for (let i = 1; i < series.length; i++) d += ` L ${x(i).toFixed(1)} ${y(vals[i]).toFixed(1)}`;
    d += ` L ${x(series.length - 1).toFixed(1)} ${costY.toFixed(1)} L ${x(0).toFixed(1)} ${costY.toFixed(1)} Z`;

    svg.appendChild(el("path", { d, fill: "var(--up)", opacity: 0.14, "clip-path": "url(#cTop)" }));
    svg.appendChild(el("path", { d, fill: "var(--down)", opacity: 0.14, "clip-path": "url(#cBot)" }));

    // cost-basis waterline (dashed)
    svg.appendChild(el("line", {
      x1: padL, y1: costY, x2: W - padR, y2: costY,
      stroke: "var(--muted)", "stroke-width": 1, "stroke-dasharray": "4 4", opacity: 0.7,
    }));

    // value line
    let ld = `M ${x(0).toFixed(1)} ${y(vals[0]).toFixed(1)}`;
    for (let i = 1; i < series.length; i++) ld += ` L ${x(i).toFixed(1)} ${y(vals[i]).toFixed(1)}`;
    const endUp = vals[vals.length - 1] >= cost;
    svg.appendChild(el("path", {
      class: "val-line", d: ld, fill: "none",
      stroke: endUp ? "var(--up)" : "var(--down)",
      "stroke-width": 2, "stroke-linejoin": "round", "stroke-linecap": "round",
    }));

    // endpoint marker
    const ex = x(series.length - 1), ey = y(vals[vals.length - 1]);
    svg.appendChild(el("circle", { cx: ex, cy: ey, r: 3.5, fill: endUp ? "var(--up)" : "var(--down)" }));

    // end date labels
    const lbl = (i, anchor, dx) => {
      const txt = el("text", {
        x: x(i) + dx, y: H - 6, "text-anchor": anchor,
        fill: "var(--muted)", "font-size": 10, "font-family": "var(--mono)",
      });
      txt.textContent = new Date(series[i].date).toLocaleDateString(undefined, { month: "short", day: "numeric" });
      svg.appendChild(txt);
    };
    lbl(0, "start", 0); lbl(series.length - 1, "end", 0);

    host.appendChild(svg);
  }

  /* ---- Market split mini-bar ---------------------------------- */
  function marketSplit(holdings) {
    let inV = 0, usV = 0;
    holdings.forEach((r) => { (r.market === "IN" ? (inV += r.value_base) : (usV += r.value_base)); });
    const tot = inV + usV || 1;
    const inPct = (inV / tot) * 100;
    $("market-split").innerHTML =
      `<span class="key"><span class="swatch" style="background:var(--accent)"></span>IN ${inPct.toFixed(0)}%</span>` +
      `<span class="bar"><span class="seg-in" style="width:${inPct}%"></span><span class="seg-us" style="width:${100 - inPct}%"></span></span>` +
      `<span class="key"><span class="swatch" style="background:#8A93C4"></span>US ${(100 - inPct).toFixed(0)}%</span>`;
  }

  /* ---- Holdings rows ------------------------------------------ */
  function rows(holdings, base) {
    const tb = $("rows");
    tb.innerHTML = "";
    const maxW = Math.max(...holdings.map((r) => r.weight_pct), 1);
    holdings.forEach((r) => {
      const tr = document.createElement("tr");
      const dayCls = signClass(r.day_pct), pnlCls = signClass(r.pnl_native);
      const spark = sparkline(r.spark, r.pnl_native >= 0);
      const stale = r.stale ? ` <span class="stale-flag" title="${r.error || "price unavailable"}">stale</span>` : "";
      tr.innerHTML =
        `<td class="l">
           <span class="sym">${r.symbol}</span><span class="mkt-tag">${r.market}</span>${stale}
           <div class="name">${r.name}</div>
         </td>
         <td class="r">${r.quantity}</td>
         <td class="r">${moneyPrecise(r.avg_cost, r.currency)}</td>
         <td class="r">${moneyPrecise(r.last, r.currency)}</td>
         <td class="r ${dayCls}">${pct(r.day_pct)}</td>
         <td class="c">${spark}</td>
         <td class="r">${money(r.value_base, base)}</td>
         <td class="r ${pnlCls}">${money(r.pnl_native, r.currency)}<div class="name ${pnlCls}">${pct(r.pnl_pct)}</div></td>
         <td class="r wgt">${r.weight_pct.toFixed(1)}%<span class="wgt-bar" style="width:${(r.weight_pct / maxW) * 46 + 4}px"></span></td>`;
      tb.appendChild(tr);
    });
  }

  function sparkline(points, positive) {
    if (!points || points.length < 2) return "";
    const w = 68, h = 22, lo = Math.min(...points), hi = Math.max(...points), s = (hi - lo) || 1;
    const step = w / (points.length - 1);
    const d = points.map((v, i) => `${i === 0 ? "M" : "L"} ${(i * step).toFixed(1)} ${(h - ((v - lo) / s) * (h - 4) - 2).toFixed(1)}`).join(" ");
    const col = positive ? "var(--up)" : "var(--down)";
    return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><path d="${d}" fill="none" stroke="${col}" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
  }

  /* ---- News --------------------------------------------------- */
  function newsLi(item, withTicker) {
    const li = document.createElement("li");
    const when = item.published ? new Date(item.published) : null;
    const whenStr = when && !isNaN(when) ? " · " + when.toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "";
    const tkr = withTicker && item.symbol ? `<span class="tkr">${item.symbol}</span> · ` : "";
    li.innerHTML = `<a href="${item.url}" target="_blank" rel="noopener">${escapeHtml(item.title)}</a>
      <span class="src">${tkr}${escapeHtml(item.source || "")}${whenStr}</span>`;
    return li;
  }
  function renderNews(news, holdings) {
    const mkt = $("market-news"); mkt.innerHTML = "";
    (news.market || []).forEach((it) => mkt.appendChild(newsLi(it, false)));
    if (!(news.market || []).length) mkt.innerHTML = '<li class="muted">No market headlines in this build.</li>';

    const hn = $("holding-news"); hn.innerHTML = "";
    const flat = [];
    holdings.forEach((r) => (news.by_symbol[r.symbol] || []).forEach((it) => flat.push(it)));
    flat.slice(0, 8).forEach((it) => hn.appendChild(newsLi(it, true)));
    if (!flat.length) hn.innerHTML = '<li class="muted">No holding-specific news in this build.</li>';
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  load();
})();
