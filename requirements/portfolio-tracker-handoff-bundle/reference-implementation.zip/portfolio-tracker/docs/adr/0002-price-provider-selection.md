# ADR 0002 — Price provider selection

**Status:** Accepted · **Date:** 2026-07-11 · Limits verified 2026-07-11

## Context
We hold both Indian (NSE/BSE) and US equities and need end-of-day closes +
short history, on free tiers, ideally keyless.

## Options and current free-tier limits

| Provider | Markets | Key? | Free tier (verified Jul 2026) | Notes |
|---|---|---|---|---|
| **yfinance** | IN + US | No | No formal limit (unofficial, scrapes Yahoo) | Simplest; breaks occasionally |
| **NSE bhavcopy** (via `jugaad-data`) | IN only | No | Unlimited, official EOD | Library absorbs NSE URL/cookie churn |
| **Twelve Data** | IN + US | Yes | 800 req/day, 8 req/min, delayed EOD | Reliable; needs a key |
| FMP | US (+intl) | Yes | 250 req/day | Rejected: tighter than Twelve Data |
| Alpha Vantage | IN + US | Yes | **25 req/day** | Rejected: a demo, not a tier |

## Decision
Two switches (`PRICE_PROVIDER_IN`, `PRICE_PROVIDER_US`), all adapters behind one
`PriceProvider` interface.

- **Default IN = `yfinance`; default US = `yfinance`.** Most liberal *and*
  keyless, so the whole app runs with zero secrets out of the box.
- **`bhavcopy`** is the recommended IN upgrade for official data / bulk accuracy.
- **`twelvedata`** is the documented US fallback when yfinance is flaky. It is
  the only option that needs a key, which lives in CI secrets (see ADR 0001,
  principle 5).

Alpha Vantage's 25/day makes it unusable for a multi-holding portfolio and is
recorded here only as a rejected alternative.

## Consequences
Swapping is a repo Variable change, e.g. `PRICE_PROVIDER_US=twelvedata` +
`TWELVEDATA_API_KEY` secret. No code changes. If Yahoo breaks, flip IN→bhavcopy
and US→twelvedata and redeploy.
