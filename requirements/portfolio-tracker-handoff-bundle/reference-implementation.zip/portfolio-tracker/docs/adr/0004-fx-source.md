# ADR 0004 — FX source for base-currency conversion

**Status:** Accepted · **Date:** 2026-07-11

## Context
Holdings span INR and USD; totals must be shown in one base currency
(`base_currency` in `settings.json`, default INR). We need one FX rate per
non-base currency, once per daily build.

## Options
| Option | Key? | Notes |
|---|---|---|
| **yfinance** (`USDINR=X`) | No | Same dep as the default price adapter |
| **exchangerate.host** | No | Open FX API, no key |
| Alpha Vantage FX | Yes | Rejected: shares the 25/day cap |

## Decision
`FX_PROVIDER=yfinance` (default) since it reuses an existing keyless dependency.
`exchangerate_host` is a keyless fallback behind the same `FxProvider`
interface.

## Consequences
- One FX call per build; if it fails the pipeline logs it and falls back to a
  1.0 rate rather than crashing (native-currency figures stay correct regardless).
- Only currencies actually present in the portfolio are fetched.
