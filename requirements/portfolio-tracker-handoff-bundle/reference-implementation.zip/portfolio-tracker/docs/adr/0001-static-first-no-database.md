# ADR 0001 — Static-first, and no database

**Status:** Accepted · **Date:** 2026-07-11

## Context
We track an end-of-day portfolio (prices, P&L, charts, news). Data changes at
most once per trading day. Two questions: do we need an always-on backend, and
do we need a database?

## Decision
**No backend, no database.** A single scheduled GitHub Action fetches data once
per day, computes everything, and writes three static JSON files
(`portfolio.json`, `history.json`, `news.json`) that the Action commits back to
the repo and publishes to GitHub Pages. The browser only reads flat files.

The "database" is Git: `history.json` is appended one point per day and
committed, giving a versioned, diffable record with zero infrastructure.

## Alternatives considered
- **Serverless function + hosted DB (Supabase / Neon free tier).** Real free
  tiers exist, but add a moving part, a second dashboard, and a place for
  secrets to leak. Rejected — nothing here needs request-time compute.
- **Client-side fetch from the browser.** Would expose API limits/keys to every
  visitor and couple cost to traffic. Rejected (violates principles 5 and 8).

## Consequences
- API usage is a function of the daily cron, not visitor count → trivially free.
- Data is at most ~1 day stale. Acceptable for an EOD tracker; documented to the
  user in the footer.
- Reset history by deleting `history.json`; it backfills from price history on
  the next run.
