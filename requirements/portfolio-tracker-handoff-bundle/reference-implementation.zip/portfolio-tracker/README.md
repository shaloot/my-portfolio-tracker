# Portfolio Tracker

An end-of-day portfolio tracker — value, P&L, per-holding charts, and news —
that rebuilds itself once a day using **only free, open, keyless** tools and
deploys **free** on GitHub Pages. No backend, no database, no paid API.

It tracks **Indian (NSE/BSE) and US** holdings together and totals them in one
base currency.

---

## How it works (the 30-second version)

```
config/holdings.json   ─┐
                        │   GitHub Action (daily cron)
config/settings.json   ─┼─▶  scripts/fetch.py  ──▶  data/*.json  ──▶  GitHub Pages
                        │    (prices + FX + news,      (committed        (static site
providers/ (adapters)  ─┘     computes P&L)             back to repo)      reads JSON)
```

One scheduled build fetches data once; every visitor reads flat files. That's
why it stays free no matter how many people open it. See `docs/adr/` for every
design decision and the alternatives considered.

**Providers are swappable by config**, all keyless by default:

| Data | Default | Alternatives (see `docs/adr/0002–0004`) |
|---|---|---|
| IN prices | `yfinance` | `bhavcopy` (official NSE), `twelvedata` |
| US prices | `yfinance` | `twelvedata` (800/day, needs key) |
| News | `rss` | — |
| FX | `yfinance` | `exchangerate_host` |

---

## Run it locally first (5 minutes, no accounts)

You need **Python 3.10+** and (for the preview QA only) **Node 18+**.

**1. Install the Python dependencies.**
```bash
pip install -r scripts/requirements.txt
```
*What this did:* installed the fetch libraries (yfinance, feedparser,
jugaad-data). All free/open-source. You should see "Successfully installed…".

**2. Build the data with the offline mock (no network, no keys).**
```bash
python scripts/fetch.py --mock
```
*What this did:* generated deterministic sample prices/news and wrote
`data/portfolio.json`, `data/history.json`, `data/news.json`. You should see a
summary line ending in "wrote portfolio.json, history.json, news.json".

**3. Assemble and preview the site.**
```bash
bash scripts/build_site.sh
cd public && python -m http.server 8000
```
*What this did:* copied the site + data into `public/` and served it. Open
**http://localhost:8000** — you should see the dashboard with the cost-basis
waterline chart, a 7-row holdings table, and sample news. Press `Ctrl+C` to stop.

**4. Now try real data** (still free, still keyless):
```bash
cd ..            # back to the repo root
python scripts/fetch.py     # no --mock -> live yfinance + RSS
bash scripts/build_site.sh && cd public && python -m http.server 8000
```
*What this did:* pulled live end-of-day prices for the sample holdings. If a
symbol fails, the row shows a "stale" flag and the app keeps working. Edit
`config/holdings.json` to your own holdings and re-run.

> **Note:** open the site through `http://localhost:8000`, **not** by
> double-clicking `index.html` — browsers block `fetch()` on `file://`.

---

## Put your own holdings in

Edit **`config/holdings.json`**. One entry per lot:
```json
{ "symbol": "TCS", "name": "Tata Consultancy", "market": "IN", "quantity": 10, "avg_cost": 3800.00 }
```
- `market`: `"IN"` (NSE/BSE) or `"US"`.
- `symbol`: the plain ticker (`TCS`, `AAPL`) — the `.NS` suffix is added for you.
- `avg_cost` and `quantity` are in the holding's own currency (INR for IN, USD for US).

Base currency and news feeds live in **`config/settings.json`**.

---

## Deploy it free on GitHub Pages

You run every command below yourself — nothing here touches your GitHub account
automatically. After you push, the included Action takes over.

**1. Create a public repo and push this project.**
```bash
git init
git add .
git commit -m "Initial portfolio tracker"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
*What this did:* published your code to GitHub. Refresh your repo page — you
should see all the files. Keep the repo **public** so Actions stay free.

**2. Turn on GitHub Pages via Actions.**
Go to your repo → **Settings → Pages** → under **Build and deployment → Source**,
choose **GitHub Actions**.
*What this did:* told GitHub to publish the site from the workflow (not a branch).
You should see "Your site is ready to be published" once the first run finishes.

**3. Let the workflow run.**
Go to the **Actions** tab → open **"Update & deploy portfolio"** → **Run workflow**.
*What this did:* ran `fetch.py` with live data, committed refreshed `data/*.json`
back to the repo, and deployed to Pages. When it finishes (green check), the job
summary shows your live URL: `https://<your-username>.github.io/<repo-name>/`.
After this it re-runs automatically every weekday evening and on every change you
push.

**4. (Optional) Switch to a keyed provider.**
Only if you want Twelve Data for US reliability:
- **Settings → Secrets and variables → Actions → Variables** → add
  `PRICE_PROVIDER_US` = `twelvedata`.
- **→ Secrets** → add `TWELVEDATA_API_KEY` = your key from twelvedata.com.
*What this did:* the next build uses Twelve Data for US symbols. The key stays in
CI and is never sent to the browser.

---

## Free-by-design guardrails

- **One fetch per day**, not per visitor → API usage is constant regardless of traffic.
- **Keyless defaults** → nothing to leak; secrets only if you opt into Twelve Data.
- **Per-symbol failures degrade gracefully** → one bad ticker never breaks the build.
- **Public repo** → GitHub Actions minutes and Pages hosting are free.

## Project layout
```
config/     holdings.json + settings.json  (what you edit)
scripts/    fetch.py, core/ (math+registry), providers/ (adapters)
site/        index.html, styles.css, app.js  (the static frontend)
data/        generated JSON (committed by CI; the "database" is git history)
docs/adr/    architecture decisions + rejected alternatives
.github/     the daily build-and-deploy workflow
```

Prices are delayed, end-of-day, and for personal tracking only — **not investment
advice.**
