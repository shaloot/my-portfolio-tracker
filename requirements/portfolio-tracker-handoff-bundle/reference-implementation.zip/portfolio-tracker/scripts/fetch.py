#!/usr/bin/env python3
"""Build-time data pipeline.

Reads config/, fetches EOD prices + FX + news through the selected adapters,
computes the portfolio, and writes the three JSON files the static site reads.
Runs in CI on a daily cron; run locally with --mock to preview with no network.

Usage:
    python fetch.py                 # use configured/default providers
    python fetch.py --mock          # deterministic offline data (no keys/network)
    python fetch.py --out ../data   # override output dir
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))          # make `core` and `providers` importable

from core import compute  # noqa: E402


def load_json(path: Path, default=None):
    try:
        return json.loads(path.read_text())
    except FileNotFoundError:
        return default


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mock", action="store_true",
                    help="use deterministic offline adapters (no network/keys)")
    ap.add_argument("--config", default=str(HERE.parent / "config"))
    ap.add_argument("--out", default=str(HERE.parent / "data"))
    args = ap.parse_args()

    if args.mock:
        os.environ.update({
            "PRICE_PROVIDER_IN": "mock", "PRICE_PROVIDER_US": "mock",
            "NEWS_PROVIDER": "mock", "FX_PROVIDER": "mock",
        })

    # Register mock adapters only if needed (keeps import graph light otherwise)
    from core import registry
    if args.mock:
        from providers.mock import MockPrices, MockNews, MockFx
        registry.PRICE_ADAPTERS["mock"] = MockPrices
        registry.NEWS_ADAPTERS["mock"] = MockNews
        registry.FX_ADAPTERS["mock"] = MockFx

    cfg_dir = Path(args.config)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    settings = load_json(cfg_dir / "settings.json", {})
    holdings = load_json(cfg_dir / "holdings.json", {}).get("holdings", [])
    holdings = [h for h in holdings if not str(h.get("symbol", "")).startswith("_")]
    if not holdings:
        print("No holdings found in config/holdings.json", file=sys.stderr)
        return 1

    base_ccy = settings.get("base_currency", "INR")
    history_days = int(settings.get("history_days", 180))

    # ---- prices, grouped by market so each market uses its own adapter -------
    quotes = {}
    by_market: dict[str, list] = {}
    for h in holdings:
        by_market.setdefault(h["market"], []).append(h)

    for market, hs in by_market.items():
        name, provider = registry.price_provider_for(market)
        print(f"[prices] {market}: {name} ({len(hs)} symbols)")
        for q in provider.get_quotes(hs, history_days):
            quotes[q.symbol] = q
            if not q.ok:
                print(f"  ! {q.symbol}: {q.error}", file=sys.stderr)

    # ---- fx: one rate per non-base currency present -------------------------
    fx_name, fx = registry.fx_provider()
    currencies = {q.currency for q in quotes.values()} | {base_ccy}
    fx_map = {base_ccy: 1.0}
    for ccy in currencies:
        if ccy == base_ccy:
            continue
        try:
            fx_map[ccy] = fx.get_rate(ccy, base_ccy)
            print(f"[fx] {fx_name}: 1 {ccy} = {fx_map[ccy]:.4f} {base_ccy}")
        except Exception as e:
            fx_map[ccy] = 1.0
            print(f"  ! fx {ccy}->{base_ccy} failed ({e}); using 1.0", file=sys.stderr)

    # ---- compute portfolio + rolling history --------------------------------
    portfolio = compute.build_portfolio(holdings, quotes, base_ccy, fx_map)
    prev_history = load_json(out_dir / "history.json", {})
    if len(prev_history.get("series", [])) < 2:
        # first run (or reset): reconstruct the curve from per-holding history
        history = compute.backfill_history(holdings, quotes, base_ccy, fx_map, history_days)
        history = compute.build_history(history, portfolio, history_days)
    else:
        history = compute.build_history(prev_history, portfolio, history_days)

    # ---- news ---------------------------------------------------------------
    news_name, news = registry.news_provider()
    feeds = settings.get("news_feeds", {})
    market_feeds = feeds.get("market", []) + feeds.get("us_market", [])
    market_items = news.get_market_news(market_feeds,
                                        int(settings.get("news_market_headlines", 8)))
    per_symbol = {}
    for h in holdings:
        try:
            items = news.get_symbol_news(h["symbol"], h.get("name", h["symbol"]),
                                         int(settings.get("news_per_holding", 3)))
            per_symbol[h["symbol"]] = [it.__dict__ for it in items]
        except Exception as e:
            print(f"  ! news {h['symbol']}: {e}", file=sys.stderr)
            per_symbol[h["symbol"]] = []
    print(f"[news] {news_name}: {len(market_items)} market headlines")

    news_out = {
        "generated_at": portfolio["generated_at"],
        "market": [it.__dict__ for it in market_items],
        "by_symbol": per_symbol,
    }

    # ---- write --------------------------------------------------------------
    (out_dir / "portfolio.json").write_text(json.dumps(portfolio, indent=2))
    (out_dir / "history.json").write_text(json.dumps(history, indent=2))
    (out_dir / "news.json").write_text(json.dumps(news_out, indent=2))

    t = portfolio["totals"]
    print(f"\n[ok] {len(holdings)} holdings | value {t['value_base']:,.0f} {base_ccy} "
          f"| P&L {t['pnl_base']:,.0f} ({t['pnl_pct']:+.2f}%) "
          f"| day {t['day_base']:,.0f} ({t['day_pct']:+.2f}%)")
    print(f"[ok] wrote portfolio.json, history.json, news.json -> {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
