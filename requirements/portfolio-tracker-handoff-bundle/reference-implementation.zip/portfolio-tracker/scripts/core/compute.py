"""Pure portfolio math. No I/O, no network — easy to reason about and test.

Given holdings + quotes + an FX rate, produce the exact JSON the site reads.
Everything the browser needs is precomputed here so the frontend stays dumb
and static (principle 4: static-first, server-never).
"""
from __future__ import annotations

from datetime import datetime, timezone

from .interfaces import Quote


def _round(x: float, n: int = 2) -> float:
    return round(float(x), n)


def build_portfolio(holdings: list[dict], quotes: dict[str, Quote],
                    base_currency: str, fx: dict[str, float]) -> dict:
    """fx maps a currency -> multiplier to convert INTO base_currency.
    (base_currency itself maps to 1.0.)
    """
    rows = []
    total_value_base = 0.0
    total_cost_base = 0.0
    total_prev_value_base = 0.0

    for h in holdings:
        sym = h["symbol"]
        q = quotes.get(sym)
        currency = q.currency if q and q.ok else ("INR" if h["market"] == "IN" else "USD")
        to_base = fx.get(currency, 1.0)

        qty = float(h["quantity"])
        avg = float(h["avg_cost"])

        if q and q.ok:
            last = q.close
            prev = q.prev_close if q.prev_close else q.close
        else:
            last = avg          # graceful fallback: show at cost, flag it
            prev = avg

        value_native = qty * last
        cost_native = qty * avg
        prev_value_native = qty * prev

        value_base = value_native * to_base
        cost_base = cost_native * to_base
        prev_value_base = prev_value_native * to_base

        total_value_base += value_base
        total_cost_base += cost_base
        total_prev_value_base += prev_value_base

        pnl_native = value_native - cost_native
        pnl_pct = (pnl_native / cost_native * 100.0) if cost_native else 0.0
        day_native = value_native - prev_value_native
        day_pct = ((last - prev) / prev * 100.0) if prev else 0.0

        rows.append({
            "symbol": sym,
            "name": h.get("name", sym),
            "market": h["market"],
            "currency": currency,
            "quantity": qty,
            "avg_cost": _round(avg, 4),
            "last": _round(last, 4),
            "prev_close": _round(prev, 4),
            "value_native": _round(value_native),
            "value_base": _round(value_base),
            "cost_base": _round(cost_base),
            "pnl_native": _round(pnl_native),
            "pnl_pct": _round(pnl_pct),
            "day_native": _round(day_native),
            "day_pct": _round(day_pct),
            "spark": [_round(p["close"], 4) for p in (q.history if q and q.ok else [])],
            "stale": not (q and q.ok),
            "error": (q.error if q and not q.ok else None),
        })

    # allocation share (by base value) added after totals known
    for r in rows:
        r["weight_pct"] = _round((r["value_base"] / total_value_base * 100.0)
                                 if total_value_base else 0.0)

    total_pnl_base = total_value_base - total_cost_base
    total_day_base = total_value_base - total_prev_value_base

    rows.sort(key=lambda r: r["value_base"], reverse=True)

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "base_currency": base_currency,
        "fx": {k: _round(v, 6) for k, v in fx.items()},
        "totals": {
            "value_base": _round(total_value_base),
            "cost_base": _round(total_cost_base),
            "pnl_base": _round(total_pnl_base),
            "pnl_pct": _round((total_pnl_base / total_cost_base * 100.0)
                              if total_cost_base else 0.0),
            "day_base": _round(total_day_base),
            "day_pct": _round((total_day_base / total_prev_value_base * 100.0)
                              if total_prev_value_base else 0.0),
        },
        "holdings": rows,
    }


def backfill_history(holdings: list[dict], quotes: dict[str, Quote],
                     base_currency: str, fx: dict[str, float], keep_days: int) -> dict:
    """Reconstruct a daily portfolio-value curve from each holding's own price
    history, so the very first deploy already shows a meaningful hero chart.
    After this, build_history() appends one fresh point per day.

    Value at each date uses the holdings you hold *now* priced at that date's
    close (a 'what this basket would have been worth' curve), converted to base.
    """
    # date -> {symbol: close}
    by_date: dict[str, dict[str, float]] = {}
    for h in holdings:
        q = quotes.get(h["symbol"])
        if not (q and q.ok):
            continue
        for pt in q.history:
            by_date.setdefault(pt["date"], {})[h["symbol"]] = pt["close"]

    cost_base = sum(float(h["quantity"]) * float(h["avg_cost"]) *
                    fx.get(quotes[h["symbol"]].currency if quotes.get(h["symbol"]) else
                           ("INR" if h["market"] == "IN" else "USD"), 1.0)
                    for h in holdings)

    series = []
    last_close: dict[str, float] = {}
    for d in sorted(by_date):
        val = 0.0
        for h in holdings:
            sym = h["symbol"]
            q = quotes.get(sym)
            ccy = q.currency if q else ("INR" if h["market"] == "IN" else "USD")
            close = by_date[d].get(sym, last_close.get(sym))
            if close is None:
                continue
            last_close[sym] = close
            val += float(h["quantity"]) * close * fx.get(ccy, 1.0)
        series.append({"date": d, "value_base": _round(val), "cost_base": _round(cost_base)})

    if keep_days and len(series) > keep_days:
        series = series[-keep_days:]
    return {"base_currency": base_currency,
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "series": series}


def build_history(prev_history: dict, portfolio: dict, keep_days: int) -> dict:
    """Append today's total base value to a rolling series for the hero chart.
    De-dups by date so re-runs on the same day overwrite rather than pile up.
    """
    series = list(prev_history.get("series", [])) if prev_history else []
    today = datetime.now(timezone.utc).date().isoformat()
    point = {
        "date": today,
        "value_base": portfolio["totals"]["value_base"],
        "cost_base": portfolio["totals"]["cost_base"],
    }
    series = [p for p in series if p.get("date") != today]
    series.append(point)
    series.sort(key=lambda p: p["date"])
    if keep_days and len(series) > keep_days:
        series = series[-keep_days:]
    return {
        "base_currency": portfolio["base_currency"],
        "generated_at": portfolio["generated_at"],
        "series": series,
    }
