"""Fixed provider contracts.

Every price or news source is an adapter behind one of these interfaces.
Swapping providers is therefore a config change (which class the registry
returns), never a rewrite of the pipeline. See docs/adr/0002 and 0003.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Iterable


@dataclass
class Quote:
    """End-of-day quote for one symbol, in the symbol's own currency."""
    symbol: str
    market: str            # "IN" or "US"
    close: float           # latest EOD close
    prev_close: float      # previous session close (for day change)
    currency: str          # "INR" or "USD"
    history: list[dict] = field(default_factory=list)  # [{date, close}], oldest->newest
    ok: bool = True
    error: str | None = None


@dataclass
class NewsItem:
    title: str
    url: str
    source: str
    published: str         # ISO8601 string
    symbol: str | None = None  # attached holding, or None for general market news


class PriceProvider(ABC):
    """Returns EOD quotes for a set of symbols in ONE market."""

    #: short id used in env/config/logs, e.g. "yfinance"
    id: str = "base"
    #: markets this adapter can serve
    markets: tuple[str, ...] = ()

    @abstractmethod
    def get_quotes(self, symbols: Iterable[dict], history_days: int) -> list[Quote]:
        """symbols: iterable of {symbol, market, name}. Returns one Quote each."""
        raise NotImplementedError


class NewsProvider(ABC):
    id: str = "base"

    @abstractmethod
    def get_market_news(self, feeds: list[str], limit: int) -> list[NewsItem]:
        raise NotImplementedError

    @abstractmethod
    def get_symbol_news(self, symbol: str, name: str, limit: int) -> list[NewsItem]:
        raise NotImplementedError


class FxProvider(ABC):
    id: str = "base"

    @abstractmethod
    def get_rate(self, base: str, quote: str) -> float:
        """Units of `quote` per 1 unit of `base`. e.g. get_rate('USD','INR')=83.x"""
        raise NotImplementedError
