"""yfinance price adapter (default, keyless).

Handles both markets: US tickers as-is, Indian tickers with a `.NS` (NSE)
suffix. Unofficial — it reads Yahoo Finance's public endpoints, which can
break without notice; that is exactly why bhavcopy/twelvedata exist behind
the same interface as swap-in alternatives (see docs/adr/0002).
"""
from __future__ import annotations

from core.interfaces import Quote, PriceProvider


def _yf_symbol(symbol: str, market: str) -> str:
    return f"{symbol}.NS" if market == "IN" else symbol


class YFinancePrices(PriceProvider):
    id = "yfinance"
    markets = ("IN", "US")

    def get_quotes(self, symbols, history_days):
        import yfinance as yf  # imported lazily so --mock needs no install

        out = []
        for s in symbols:
            sym, market = s["symbol"], s["market"]
            currency = "INR" if market == "IN" else "USD"
            try:
                t = yf.Ticker(_yf_symbol(sym, market))
                df = t.history(period=f"{max(history_days, 7)}d",
                               interval="1d", auto_adjust=False)
                if df is None or df.empty:
                    raise ValueError("no rows returned")
                closes = df["Close"].dropna()
                hist = [{"date": idx.date().isoformat(), "close": float(v)}
                        for idx, v in closes.items()]
                close = hist[-1]["close"]
                prev = hist[-2]["close"] if len(hist) > 1 else close
                out.append(Quote(symbol=sym, market=market, close=close,
                                 prev_close=prev, currency=currency, history=hist))
            except Exception as e:  # never let one bad symbol kill the run
                out.append(Quote(symbol=sym, market=market, close=0, prev_close=0,
                                 currency=currency, ok=False, error=str(e)[:200]))
        return out
