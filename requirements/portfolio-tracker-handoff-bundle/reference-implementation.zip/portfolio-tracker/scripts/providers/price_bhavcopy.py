"""Official NSE EOD adapter (keyless, India only).

Pulls the same end-of-day data NSE publishes in the daily *bhavcopy*, via the
maintained `jugaad-data` library, which absorbs NSE's periodic URL/cookie
changes and anti-scraping headers for you (hand-rolling those URLs is the
classic way this breaks — see docs/adr/0002).

Use it as the India provider by setting  PRICE_PROVIDER_IN=bhavcopy .
US symbols are rejected — pair with yfinance/twelvedata for US.
"""
from __future__ import annotations

from datetime import date, timedelta

from core.interfaces import Quote, PriceProvider


class BhavcopyPrices(PriceProvider):
    id = "bhavcopy"
    markets = ("IN",)

    def get_quotes(self, symbols, history_days):
        from jugaad_data.nse import stock_df  # lazy import

        out = []
        to_d = date.today()
        from_d = to_d - timedelta(days=max(history_days, 10) + 10)  # pad for holidays
        for s in symbols:
            sym, market = s["symbol"], s["market"]
            if market != "IN":
                out.append(Quote(symbol=sym, market=market, close=0, prev_close=0,
                                 currency="USD", ok=False,
                                 error="bhavcopy serves Indian equities only"))
                continue
            try:
                df = stock_df(symbol=sym, from_date=from_d, to_date=to_d, series="EQ")
                if df is None or df.empty:
                    raise ValueError("no rows returned")
                df = df.sort_values("DATE")
                hist = [{"date": d.isoformat() if hasattr(d, "isoformat") else str(d),
                         "close": float(c)}
                        for d, c in zip(df["DATE"], df["CLOSE"])]
                close = hist[-1]["close"]
                prev = hist[-2]["close"] if len(hist) > 1 else close
                out.append(Quote(symbol=sym, market="IN", close=close,
                                 prev_close=prev, currency="INR", history=hist))
            except Exception as e:
                out.append(Quote(symbol=sym, market="IN", close=0, prev_close=0,
                                 currency="INR", ok=False, error=str(e)[:200]))
        return out
