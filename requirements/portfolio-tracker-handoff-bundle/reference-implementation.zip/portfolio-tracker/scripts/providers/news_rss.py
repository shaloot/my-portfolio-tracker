"""RSS news adapter (default, keyless, effectively unlimited).

Market headlines come from the feeds in config/settings.json. Per-holding news
uses Google News' keyless RSS search, which gives clean company-specific items
without an API key or quota (see docs/adr/0003).
"""
from __future__ import annotations

import urllib.parse

from core.interfaces import NewsItem, NewsProvider

_GNEWS = "https://news.google.com/rss/search"


def _entries(url: str):
    import feedparser
    return feedparser.parse(url).entries


def _to_item(e, source: str, symbol=None) -> NewsItem:
    return NewsItem(
        title=getattr(e, "title", "").strip(),
        url=getattr(e, "link", ""),
        source=getattr(getattr(e, "source", None), "title", source) or source,
        published=getattr(e, "published", "") or getattr(e, "updated", ""),
        symbol=symbol,
    )


class RssNews(NewsProvider):
    id = "rss"

    def get_market_news(self, feeds, limit):
        items, seen = [], set()
        for url in feeds:
            for e in _entries(url):
                it = _to_item(e, source="Markets")
                if it.title and it.url not in seen:
                    seen.add(it.url)
                    items.append(it)
        return items[:limit]

    def get_symbol_news(self, symbol, name, limit):
        q = urllib.parse.urlencode({"q": f'"{name}" stock', "hl": "en-IN",
                                    "gl": "IN", "ceid": "IN:en"})
        items = []
        for e in _entries(f"{_GNEWS}?{q}"):
            it = _to_item(e, source="Google News", symbol=symbol)
            if it.title:
                items.append(it)
            if len(items) >= limit:
                break
        return items
