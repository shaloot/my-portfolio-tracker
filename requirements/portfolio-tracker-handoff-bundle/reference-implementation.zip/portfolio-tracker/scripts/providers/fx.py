"""FX adapters for converting holdings into the base currency.

Two keyless options (see docs/adr/0004):
  - yfinance         : reads the `USDINR=X` style pair from Yahoo (default)
  - exchangerate_host: open exchangerate.host API, no key
"""
from __future__ import annotations

import json
import urllib.request

from core.interfaces import FxProvider


class YFinanceFx(FxProvider):
    id = "yfinance"

    def get_rate(self, base, quote):
        if base == quote:
            return 1.0
        import yfinance as yf
        pair = f"{base}{quote}=X"
        df = yf.Ticker(pair).history(period="5d", interval="1d")
        if df is None or df.empty:
            raise ValueError(f"no FX data for {pair}")
        return float(df["Close"].dropna().iloc[-1])


class ExchangerateHostFx(FxProvider):
    id = "exchangerate_host"

    def get_rate(self, base, quote):
        if base == quote:
            return 1.0
        url = f"https://api.exchangerate.host/latest?base={base}&symbols={quote}"
        with urllib.request.urlopen(url, timeout=30) as r:
            data = json.load(r)
        rate = data.get("rates", {}).get(quote)
        if not rate:
            raise ValueError(f"no FX rate {base}->{quote}")
        return float(rate)
