"""Deterministic mock adapters.

Selected when PRICE_PROVIDER_*/NEWS_PROVIDER/FX_PROVIDER = "mock" (or via
`python fetch.py --mock`). They generate stable pseudo-random series from the
symbol name so runs are reproducible. This lets you build, test the math, and
preview the site with zero network and zero keys.
"""
from __future__ import annotations

import hashlib
import math
from datetime import date, timedelta

from core.interfaces import Quote, NewsItem, PriceProvider, NewsProvider, FxProvider


def _seed(text: str) -> float:
    h = hashlib.sha256(text.encode()).hexdigest()
    return int(h[:8], 16) / 0xFFFFFFFF  # 0..1


class MockPrices(PriceProvider):
    id = "mock"
    markets = ("IN", "US")

    def get_quotes(self, symbols, history_days):
        out = []
        for s in symbols:
            sym = s["symbol"]
            currency = "INR" if s["market"] == "IN" else "USD"
            base = 50 + _seed(sym) * (2500 if currency == "INR" else 400)
            drift = (_seed(sym + "d") - 0.45) * 0.004  # slight up/down bias
            vol = 0.012 + _seed(sym + "v") * 0.02
            hist = []
            price = base
            days = min(history_days, 180)
            start = date.today() - timedelta(days=days)
            for i in range(days):
                wobble = math.sin(i / 6.0 + _seed(sym) * 6) * vol
                price = max(1.0, price * (1 + drift + wobble * 0.4))
                hist.append({"date": (start + timedelta(days=i)).isoformat(),
                             "close": round(price, 4)})
            close = hist[-1]["close"]
            prev = hist[-2]["close"] if len(hist) > 1 else close
            out.append(Quote(symbol=sym, market=s["market"], close=close,
                             prev_close=prev, currency=currency, history=hist))
        return out


class MockNews(NewsProvider):
    id = "mock"

    def get_market_news(self, feeds, limit):
        items = []
        for i in range(min(limit, 6)):
            items.append(NewsItem(
                title=f"Markets close mixed as sectors diverge (sample {i+1})",
                url="https://example.com/market-news",
                source="Mock Wire", published=f"2026-07-1{i%9}T09:30:00Z"))
        return items

    def get_symbol_news(self, symbol, name, limit):
        return [NewsItem(
            title=f"{name} in focus after quarterly update (sample)",
            url="https://example.com/" + symbol.lower(),
            source="Mock Wire", published="2026-07-10T14:00:00Z", symbol=symbol)]


class MockFx(FxProvider):
    id = "mock"

    def get_rate(self, base, quote):
        table = {("USD", "INR"): 83.2, ("INR", "USD"): 1 / 83.2}
        return table.get((base, quote), 1.0)
